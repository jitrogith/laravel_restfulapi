<?php if(Route::current()->uri == 'buku'): ?>
  <?php echo method_field('post'); ?>
<?php endif; ?>

<?php if(Route::current()->uri == 'buku/{id}'): ?>
  <?php echo method_field('put'); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\laravel_api\resources\views/buku/method.blade.php ENDPATH**/ ?>